import React from 'react'
import axios from "axios";
import {useAppContext} from '../../contexts/AppProvider'
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';

import './index.css'

export default function Header() {
    const { state, dispatch } = useAppContext();
    const { user } = state;
    
    const navigate = useNavigate();
    const signOut = () => {
        localStorage.removeItem("token")
        //reset user to null
        dispatch({ type: "CURRENT_USER", payload: null });
    };
    return (
        <header className="header">
            <h1 className="logo">
                <Link to='/'>twitter</Link> 
            </h1>
            <nav>
                <ul className="main-nav">
                    {user ? (
                        <>
                            <li>
                                <span className="user-name">Hello ,{user.userName}</span>
                            </li>
                            <li onClick={() => signOut()}>
                                <span>Sing Out </span>
                            </li>
                        </>
                    ) : (
                        <>
                            <li>
                                <Link to='/login'>Login</Link>
                            </li>
                            <li><Link to='/register'>register</Link></li>
                        </>
                    )
                    }

                </ul>
            </nav>
        </header>
    )
}


