import React, { useEffect } from "react";
import { useState } from "react";
import axios from "axios";

export default function PostItem({ post, setWillUpdate }) {
  const [hide, setHide] = useState(true);
  const [HideDelete, setHideDelete] = useState(true);
  const [content, setContent] = useState("");

  useEffect(() => {
    setContent(post.content);
  }, [post]);

  const today = new Date().getTime();
  const t1 = new Date(post.createdAt).getTime();
  const day = parseInt((today - t1) / (24 * 3600 * 1000));

  const deletePost = async () => {
    const option = {
      method: "delete",
      url: "http://localhost:5000/api/v1/posts/" + post._id,
    };
    await axios(option);

    setWillUpdate((prev) => prev + 1);
  };

  const updateContent = async () => {
    const token = localStorage.getItem("token");

    const option = {
      method: "put",
      url: "http://localhost:5000/api/v1/posts/" + post._id,
      data: {
        ...post,
        content,
      },
      headers: {
        authorization: token,
      },
    };
    await axios(option);

    setWillUpdate((prev) => prev + 1);
  };

  return (
    <div className="post-item">
      <p className="post-content">{post.content}</p>
      <div className="post-footer">
        <div className="post-infors">
          <span>by. {post.author.name}</span>
          <span>{day} NGÀY TRƯỚC</span>
        </div>
        <div className="post-edit-delete">
          <span onClick={() => setHide((prev) => !prev)}>Edit</span>
          <span onClick={() => setHideDelete((prev) => !prev)}>Delete</span>
          <div className={` ${HideDelete ? "hide" : ""}`}>
            <span className="delete-question">Are you sure?</span>
            <span onClick={deletePost}>Yes</span>
            <span onClick={() => setHideDelete((prev) => !prev)}>No</span>
          </div>
        </div>
      </div>
      <div className={`post-edit-form ${hide ? "hide" : ""}`}>
        <form className="edit-form">
          <textarea
            type="text"
            name="content"
            id="content"
            className="content"
            placeholder="What's happening"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          ></textarea>
          <div className={`btn-container`}>
            <button className="btn" type="button" onClick={updateContent}>
              Update
            </button>
            <button
              className="btn"
              type="button"
              onClick={() => setHide((prev) => !prev)}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
