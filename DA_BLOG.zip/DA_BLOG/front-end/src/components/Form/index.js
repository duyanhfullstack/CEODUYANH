import React from 'react'
import { useState } from 'react'
import axios from "axios";
import {useAppContext} from "../../contexts/AppProvider";
import { useNavigate } from 'react-router-dom';

import './index.css'

export default function Form() {
    const { dispatch } = useAppContext(); 
    const [post, setPost] = useState("");
    const navigate = useNavigate();
    const onChageHandle = (e) =>  {
        setPost(e.target.value);
    };
    
    const onSubmitHandle = async (e)=> {
        try {
            e.preventDefault();

            const token = localStorage.getItem("token");

            const option = {
                method: "post",
                url: "http://localhost:5000/api/v1/posts",
                data: {
                    content: post
                },
                headers: {
                    authorization: token
                  }
            };
            const response =  await axios(option);

            console.log(response)

        } catch (error) {    
            console.log(error);
           
        }
    }
    return (
        <section className="form-section">
            <form className="form" onSubmit={onSubmitHandle}>
                <textarea
                type="text"
                name="content"
                id="content"
                className="content"
                placeholder="what's happening"
                onChange = {onChageHandle}
                value= {post} 
                > 
                    
                </textarea >
                <button className="btn" type="submit">Tweet</button>
            </form>
        </section>
    )
}