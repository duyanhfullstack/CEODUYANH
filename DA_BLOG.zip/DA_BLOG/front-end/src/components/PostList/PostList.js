import React, { useCallback, useState } from "react";
import { useEffect } from "react";
import PostItem from "../PostItem/PostItem";
import "../PostList/PostList.css";
import axios from "axios";
export default function PostList() {
  const [posts, setPosts] = useState([]);
  const [willUpdate, setWillUpdate] = useState(1);
  const [post, setPost] = useState("");

  const getAllPosts = useCallback(async () => {
    try {
      const option = {
        method: "get",
        url: "http://localhost:5000/api/v1/posts",
      };
      const response = await axios(option);
      setPosts(response.data.data);
    } catch (error) {
      console.log(error);
    }
  }, []);

  const onChageHandle = (e) => {
    setPost(e.target.value);
  };

  const onSubmitHandle = async (e) => {
    try {
      e.preventDefault();

      const token = localStorage.getItem("token");

      const option = {
        method: "post",
        url: "http://localhost:5000/api/v1/posts",
        data: {
          content: post,
        },
        headers: {
          authorization: token,
        },
      };

      await axios(option);

      setWillUpdate((prev) => prev + 1);
      setPost("");
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getAllPosts();
  }, [getAllPosts, willUpdate]);

  return (
    <>
      <section className="form-section">
        <form className="form" onSubmit={onSubmitHandle}>
          <textarea
            type="text"
            name="content"
            id="content"
            className="content"
            placeholder="what's happening"
            onChange={onChageHandle}
            value={post}
          ></textarea>
          <button className="btn" type="submit">
            Tweet
          </button>
        </form>
      </section>
      <section className="post-section">
        <div className="post-list">
          {posts.map((post) => (
            <PostItem post={post} setWillUpdate={setWillUpdate} />
          ))}
        </div>
      </section>
    </>
  );
}
