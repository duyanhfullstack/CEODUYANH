import React from 'react'
import PostList from '../PostList/PostList'

export default function Main() {
    return (
        <div>
            <PostList />
        </div>
    )
}
