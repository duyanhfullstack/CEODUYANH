import Header from "./components/Header";
import "./styles/variables.css";
import "./styles/global.css";
import Main from "./components/Main/Main";
import Login from "./components/Login/Login";
import Register from "./components/Register/Register";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import AppProvider from "./contexts/AppProvider";
function App() {
  return (
    <AppProvider>
      <div className="container">
        <BrowserRouter>
          <Header />
          <Routes>
            <Route exact path="/login" element={<Login />}></Route>
            <Route exact path="/register" element={<Register />}></Route>
            <Route exact path="/" element={<Main />}></Route>
            <Route exact path="*" element={<div>Page Not Found</div>}></Route>
          </Routes>
        </BrowserRouter>
      </div>
    </AppProvider>
  );
}

export default App;
