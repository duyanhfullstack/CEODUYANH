import React, { createContext, useContext , useReducer } from "react";

import AppReducer from '../reducers/AppReducer'

const AppContext = createContext();

const AppProvider = (props) => {
    const initialState = {user: null, posts:[]}

    const[state, dispatch] = useReducer(AppReducer, initialState);

  return <AppContext.Provider value={{state, dispatch}}>{props.children}</AppContext.Provider>;
};

export const useAppContext = () => {
  const context = useContext(AppContext);

  if (context === undefined) {
    throw new Error(`useContext must be used within a Provider`);
  }

  return context;
};

export default AppProvider;
