const express =  require('express');

const {getAllPosts,createOnePost, updateOnePost, deleteOnepost} = require('../controllers/postController.js');
const { updateOne } = require('../models/User');
const  {verifyToken} = require('../middleware/verifyToken')

const Router = express.Router();

Router.route('/').get(getAllPosts).post(verifyToken, createOnePost);

Router.route('/:postId').put(verifyToken, updateOnePost).delete(deleteOnepost);


module.exports = Router;