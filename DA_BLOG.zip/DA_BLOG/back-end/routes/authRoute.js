const express =  require('express');
const {login, register, getCurentUser} =  require('../controllers/authController');
const { checkCurentUser } = require('../middleware/checkCurrentUser');
const Router = express.Router();

Router.route('/register').post(register);
Router.route('/login').post(login);
Router.route('/').get(checkCurentUser, getCurentUser);

module.exports = Router;
