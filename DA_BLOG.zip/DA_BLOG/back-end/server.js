//config dotenv
require('dotenv').config();



const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose')

const app = express();
//import Routes
const authRoute = require('./routes/authRoute');
const postRoute = require('./routes/postRoute');
//import errorHandlers
const {errorHandler} = require('./middleware/ErrorHandler')

const {register} = require('./controllers/authController')
const port = process.env.APP_PORT;

//Cors
app.use(cors());

//BodyParSer
app.use(express.json())

const API_VERSION = "/api/v1"

//Mount the route
app.use(`${API_VERSION}/auth`,  authRoute);
app.use(`${API_VERSION}/posts`, postRoute);
//unhandled Route
app.all('*',(req,res,next)=>{
  const err = new Error('The route can not be found');
  err.statusCode = 404;
  next(err);
});
app.use(errorHandler);

const URI = process.env.MONGODB_URL
mongoose.connect(URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}, () => {
  console.log("Connected to MongoDB")
})


app.listen(port, () => {
  console.log(`server is running on port ${port}`);
})